package student_registration;
public class Registration {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("STUDENT REGISTRATION SYSTEM!!!");
		College college=new College();
		college.display();
		Course course=new Course();
		course.getCourse();
		System.out.println("Registration Successfull.");
	}
 
}
